export class CreateGamificationDto {}
