export class Gamification {}
